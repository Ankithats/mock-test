from django.db import models

# Create your models here.

class Contacts(models.Model):
    name=models.CharField(max_length=250)
    phone=models.IntegerField()
    email=models.EmailField()  
    image=models.ImageField(upload_to='profiles',blank=True)  

def __str__(self):
    return self.name
