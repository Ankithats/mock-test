from django.shortcuts import render,redirect
from .models import Contacts
# Create your views here.
def home(req):
    contacts=Contacts.objects.all()
    return render(req,'index.html',{contacts:contacts})
def indu(req):
    # contacts=Contacts.objects.get(id=)
    return render(req,'indu.html')
def call(req):
    # contacts=Contacts.objects.get(id=id)
    return render(req,'call.html',)

def add(req):
    if req.method=='Post': 
        name=req.POST.get('name','')
        phone=req.POST.get('phone','')
        email=req.POST.get('email','')
        image=req.FILES['images']
        contacts=Contacts(name=name,phone=phone,email=email,image=image)
        contacts.save()
    return render('add.html',{contacts:contacts})

def edit(req,id):
    contacts=Contacts.objects.get(id=id)
    if req.method=='post':
        name=req.POST.get('name','')
        phone=req.POST.get('phone','')
        image=req.FILES['image']
        contacts=Contacts.objects.filter(id=id).update(name=name,phone=phone,image=image) 
        return redirect('home')
    return render(req,'edit.html',{contacts:contacts})
def delete(req,id):
    contacts=Contacts.objects.get(id=id)
    Contacts.delete()
    return render(req,'delete.html',{contacts:contacts})