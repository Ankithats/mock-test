from django.urls import path
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('add/',views.add,name='add'),
    path('indu/',views.indu,name='indu'),
     path('call/',views.call,name='call'),
     path('edit/',views.edit,name='edit'),
     path('delete/',views.delete,name='delete'),
    
    
    
]
